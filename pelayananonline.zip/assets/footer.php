<footer class="sticky-footer bg-white">
    <div class="container my-auto">
        <div class="copyright text-center my-auto">
            <span>Created by <a href="mailto:narayaitsolution@gmail.com">us </a> for Fakultas Humaniora UIN Malang ver. 1.18</span>
        </div>
    </div>
</footer>